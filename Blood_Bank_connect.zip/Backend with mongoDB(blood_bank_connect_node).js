const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs'); // currently unused (reserved for auth)
const jwt = require('jsonwebtoken'); // currently unused (reserved for auth)
const nodemailer = require('nodemailer');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const validator = require('validator');
const path = require('path');
require('dotenv').config();

const app = express();


app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5000',
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));


const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests from this IP, please try again later.' },
});
app.use('/api/', limiter);

mongoose
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/bloodbank', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch((err) => console.error('❌ MongoDB connection error:', err));



// Quiz Result Schema (aligns with frontend quiz)
const quizResultSchema = new mongoose.Schema({
  sessionId: { type: String, required: true },
  answers: [
    {
      question: String,
      answer: Boolean,
      questionIndex: Number,
    },
  ],
  questionsAnswered: {
    type: [String],
    default: [
      'Are you between the age of 17-60?',
      'Do you weigh 50kg and more?',
      'Have you had a tattoo or needle stick within the last six (6) months?',
      'Are you currently taking any medications?',
      'Do you feel healthy and well today?',
    ],
  },
  isEligible: { type: Boolean, required: true },
  score: { type: Number, required: true },
  ipAddress: { type: String },
  userAgent: { type: String },
  completedAt: { type: Date, default: Date.now },
});

// Appointment Schema (aligns with booking form)
const appointmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, trim: true },
    phone: { type: String, required: true, trim: true },
    gender: { type: String, enum: ['male', 'female', 'other'], required: true },
    appointmentDate: { type: Date, required: true },
    appointmentTime: {
      type: String,
      enum: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
      required: true,
    },
    status: {
      type: String,
      enum: ['scheduled', 'confirmed', 'completed', 'cancelled', 'no-show'],
      default: 'scheduled',
    },
    bloodType: {
      type: String,
      enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
    },
    notes: { type: String, trim: true },
    reminderSent: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Contact Message Schema
const contactMessageSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
    email: { type: String, trim: true },
    message: { type: String, required: true, trim: true },
    status: { type: String, enum: ['new', 'read', 'replied', 'resolved'], default: 'new' },
    ipAddress: { type: String },
    userAgent: { type: String },
    replied: { type: Boolean, default: false },
    replyMessage: { type: String },
    repliedAt: { type: Date },
    repliedBy: { type: String },
  },
  { timestamps: true }
);

// User Schema (reserved for auth)
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, trim: true, lowercase: true },
    phone: { type: String, required: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    bloodType: { type: String, enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
    gender: { type: String, enum: ['male', 'female', 'other'] },
    dateOfBirth: { type: Date },
    address: { type: String, trim: true },
    isEligible: { type: Boolean, default: false },
    lastDonation: { type: Date },
    totalDonations: { type: Number, default: 0 },
    role: { type: String, enum: ['donor', 'admin', 'staff'], default: 'donor' },
    isActive: { type: Boolean, default: true },
    emailVerified: { type: Boolean, default: false },
    phoneVerified: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Location Schema
const locationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    address: { type: String, required: true },
    city: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String, required: true },
    operatingHours: {
      monday: { open: String, close: String, closed: { type: Boolean, default: false } },
      tuesday: { open: String, close: String, closed: { type: Boolean, default: false } },
      wednesday: { open: String, close: String, closed: { type: Boolean, default: false } },
      thursday: { open: String, close: String, closed: { type: Boolean, default: false } },
      friday: { open: String, close: String, closed: { type: Boolean, default: false } },
      saturday: { open: String, close: String, closed: { type: Boolean, default: false } },
      sunday: { open: String, close: String, closed: { type: Boolean, default: true } },
    },
    coordinates: { latitude: Number, longitude: Number },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Newsletter Schema
const newsletterSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true, trim: true, lowercase: true },
    name: { type: String, trim: true },
    subscribed: { type: Boolean, default: true },
    source: { type: String, default: 'website' },
    subscribedAt: { type: Date, default: Date.now },
    unsubscribedAt: { type: Date },
  },
  { timestamps: true }
);

// Models
const QuizResult = mongoose.model('QuizResult', quizResultSchema);
const Appointment = mongoose.model('Appointment', appointmentSchema);
const ContactMessage = mongoose.model('ContactMessage', contactMessageSchema);
const User = mongoose.model('User', userSchema);
const Location = mongoose.model('Location', locationSchema);
const Newsletter = mongoose.model('Newsletter', newsletterSchema);


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

transporter.verify((error) => {
  if (error) console.log('❌ Email configuration error:', error);
  else console.log('✅ Email server ready');
});


const generateSessionId = () =>
  Math.random().toString(36).slice(2) +
  Math.random().toString(36).slice(2) +
  Date.now().toString(36);

const getClientInfo = (req) => {
  const fwd = req.headers['x-forwarded-for'];
  const ipFromHeader = Array.isArray(fwd) ? fwd[0] : (fwd || '').split(',')[0].trim();
  return {
    ipAddress: ipFromHeader || req.ip || req.connection?.remoteAddress,
    userAgent: req.get('User-Agent') || 'Unknown',
  };
};

// Email Templates
const emailTemplates = {
  appointmentConfirmation: (appointmentData) => ({
    subject: '🩸 Appointment Confirmed - Blood Bank Connect',
    html: `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;text-align:center;border-radius:10px 10px 0 0}.content{background:#f9f9f9;padding:30px;border-radius:0 0 10px 10px}.highlight{background:#ff4757;color:#fff;padding:15px;border-radius:5px;margin:20px 0}.details{background:#fff;padding:20px;border-radius:5px;margin:20px 0}.footer{text-align:center;padding:20px;color:#666}.button{display:inline-block;background:#ff4757;color:#fff;padding:12px 25px;text-decoration:none;border-radius:25px;margin:10px}</style></head><body><div class="container"><div class="header"><h1>🩸 Blood Bank Connect</h1><h2>Appointment Confirmed!</h2></div><div class="content"><p>Dear <strong>${appointmentData.name}</strong>,</p><p>Thank you for choosing to save lives! Your blood donation appointment has been successfully confirmed.</p><div class="highlight"><h3>📅 Appointment Details</h3></div><div class="details"><p><strong>📅 Date:</strong> ${new Date(appointmentData.appointmentDate).toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</p><p><strong>⏰ Time:</strong> ${appointmentData.appointmentTime}</p><p><strong>📍 Location:</strong> Blood Bank Connect Center<br>Local address, Kumasi, Ghana</p><p><strong>📞 Phone:</strong> ${appointmentData.phone}</p></div><div class="highlight"><h3>💡 Important Reminders</h3></div><ul><li><strong>🍎 Eat Well:</strong> Have a healthy meal 2-3 hours before donation</li><li><strong>💧 Stay Hydrated:</strong> Drink plenty of water before and after</li><li><strong>🪪 Bring ID:</strong> Valid government-issued photo ID required</li><li><strong>😴 Rest Well:</strong> Get adequate sleep the night before</li><li><strong>🚭 Avoid:</strong> Alcohol 24 hours before donation</li></ul><div class="details"><h3>❓ What to Expect</h3><p>The entire process takes about 45-60 minutes:</p><ul><li>Registration & Health Screening (15 min)</li><li>Blood Donation (8-10 min)</li><li>Rest & Refreshments (15 min)</li></ul></div><p style="text-align:center"><strong>Need to reschedule or have questions?</strong><br><a href="tel:+233503489235" class="button">📞 Call Us</a><a href="mailto:bloodbankconnect@gmail.com" class="button">📧 Email Us</a></p><p style="text-align:center;font-size:18px;color:#ff4757"><strong>🎯 Your donation can save up to 3 lives!</strong></p></div><div class="footer"><p>Blood Bank Connect - Making a difference, one donation at a time</p><p>📞 +233503489235 | 📧 bloodbankconnect@gmail.com</p></div></div></body></html>`
  }),
  contactConfirmation: (contactData) => ({
    subject: '✅ Message Received - Blood Bank Connect',
    html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto"><div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;text-align:center"><h1>🩸 Blood Bank Connect</h1><h2>Message Received!</h2></div><div style="padding:30px;background:#f9f9f9"><p>Dear <strong>${contactData.name}</strong>,</p><p>Thank you for contacting Blood Bank Connect! We have received your message and will get back to you soon.</p><div style="background:#fff;padding:20px;border-radius:5px;margin:20px 0"><h3>Your Message:</h3><p style="font-style:italic;color:#666">"${contactData.message}"</p></div><div style="text-align:center;margin:30px 0"><p style="color:#ff4757;font-weight:bold">Need immediate assistance?</p><p>📞 +233503489235<br>📧 bloodbankconnect@gmail.com</p></div></div><div style="text-align:center;padding:20px;color:#666"><p>Blood Bank Connect - We are here to help you</p></div></div>`
  }),
};



// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Blood Bank Connect API is running',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '1.0.1',
  });
});

// API Info
app.get('/api', (req, res) => {
  res.json({
    name: 'Blood Bank Connect API',
    version: '1.0.1',
    description: 'Backend API for Blood Bank Connect - Connecting donors with recipients',
    endpoints: {
      quiz: '/api/quiz/submit',
      appointments: '/api/appointments/*',
      contact: '/api/contact',
      locations: '/api/locations',
      newsletter: '/api/newsletter/subscribe',
    },
  });
});

// Quiz 
app.post('/api/quiz/submit', async (req, res) => {
  try {
    const { answers, sessionId } = req.body;
    const clientInfo = getClientInfo(req);

    if (!answers || !Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ success: false, error: 'Quiz answers are required' });
    }

    const questions = [
      'Are you between the age of 17-60?',
      'Do you weigh 50kg and more?',
      'Have you had a tattoo or needle stick within the last six (6) months?',
      'Are you currently taking any medications?',
      'Do you feel healthy and well today?',
    ];

    const criticalAnswers = [true, true, false]; // age ok, weight ok, no recent tattoo
    let score = 0;
    let isEligible = true;

    // Critical evaluation
    for (let i = 0; i < Math.min(answers.length, criticalAnswers.length); i++) {
      if (answers[i].answer === criticalAnswers[i]) score++;
      else isEligible = false;
    }

    // Additional scoring
    for (let i = criticalAnswers.length; i < answers.length; i++) {
      if (answers[i].answer === true) score++;
    }

    const quizResult = new QuizResult({
      sessionId: sessionId || generateSessionId(),
      answers: answers.map((a, idx) => ({
        question: questions[idx] || `Question ${idx + 1}`,
        answer: !!a.answer,
        questionIndex: idx,
      })),
      isEligible,
      score,
      ...clientInfo,
    });

    await quizResult.save();

    res.json({
      success: true,
      isEligible,
      score,
      totalQuestions: answers.length,
      sessionId: quizResult.sessionId,
      message: isEligible
        ? 'Congratulations! You are one step closer to saving up to three lives.'
        : 'Thank you for your interest. Based on your answers, you may not be eligible to donate at this time. Please consult with our medical staff for more information.',
      recommendation: isEligible ? 'book_appointment' : 'contact_us',
    });
  } catch (error) {
    console.error('Quiz submission error:', error);
    res.status(500).json({ success: false, error: 'Unable to process quiz submission. Please try again.' });
  }
});

app.get('/api/quiz/stats', async (req, res) => {
  try {
    const total = await QuizResult.countDocuments();
    const eligible = await QuizResult.countDocuments({ isEligible: true });
    const recent = await QuizResult.find().sort({ completedAt: -1 }).limit(10).select('isEligible score completedAt');

    res.json({
      success: true,
      stats: {
        total,
        eligible,
        ineligible: total - eligible,
        eligibilityRate: total > 0 ? Number(((eligible / total) * 100).toFixed(1)) : 0,
      },
      recent,
    });
  } catch (error) {
    console.error('Quiz stats error:', error);
    res.status(500).json({ success: false, error: 'Unable to fetch quiz statistics' });
  }
});

// ---- Appointments ----
app.post('/api/appointments/book', async (req, res) => {
  try {
    const { name, phone, email, gender, date, time } = req.body;

    if (!name || !phone || !gender || !date || !time) {
      return res.status(400).json({ success: false, error: 'All required fields must be filled: name, phone, gender, date, and time' });
    }

    if (email && !validator.isEmail(email)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address' });
    }

    const appointmentDate = new Date(date);
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    if (appointmentDate < now) {
      return res.status(400).json({ success: false, error: 'Appointment date cannot be in the past' });
    }

    const validTimeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];
    if (!validTimeSlots.includes(time)) {
      return res.status(400).json({ success: false, error: 'Please select a valid time slot' });
    }

    // Normalize to day range (local timezone)
    const startOfDay = new Date(appointmentDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(appointmentDate);
    endOfDay.setHours(23, 59, 59, 999);

    const existingAppointment = await Appointment.findOne({
      appointmentDate: { $gte: startOfDay, $lte: endOfDay },
      appointmentTime: time,
      status: { $in: ['scheduled', 'confirmed'] },
    });

    if (existingAppointment) {
      return res.status(400).json({ success: false, error: 'This time slot is already booked. Please choose another time.' });
    }

    const appointment = new Appointment({
      name: name.trim(),
      phone: phone.trim(),
      email: email ? email.trim() : undefined,
      gender,
      appointmentDate,
      appointmentTime: time,
    });

    await appointment.save();

    if (email) {
      try {
        const emailTemplate = emailTemplates.appointmentConfirmation({
          name,
          phone,
          appointmentDate,
          appointmentTime: time,
        });

        await transporter.sendMail({
          from: `"Blood Bank Connect" <${process.env.EMAIL_USER}>`,
          to: email,
          subject: emailTemplate.subject,
          html: emailTemplate.html,
        });
        console.log('✅ Appointment confirmation email sent to:', email);
      } catch (emailError) {
        console.error('❌ Email sending failed:', emailError);
      }
    }

    res.status(201).json({
      success: true,
      message: 'Appointment booked successfully! We will contact you shortly to confirm.',
      appointment: {
        id: appointment._id,
        name: appointment.name,
        date: appointment.appointmentDate,
        time: appointment.appointmentTime,
        status: appointment.status,
      },
    });
  } catch (error) {
    console.error('Appointment booking error:', error);
    res.status(500).json({ success: false, error: 'Unable to book appointment. Please try again or contact us directly.' });
  }
});

app.get('/api/appointments/available-slots', async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) {
      return res.status(400).json({ success: false, error: 'Date parameter is required' });
    }

    const qDate = new Date(date);
    const allSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];

    const start = new Date(qDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(qDate);
    end.setHours(23, 59, 59, 999);

    const bookedAppointments = await Appointment.find({
      appointmentDate: { $gte: start, $lte: end },
      status: { $in: ['scheduled', 'confirmed'] },
    }).select('appointmentTime');

    const bookedSlots = bookedAppointments.map((a) => a.appointmentTime);
    const availableSlots = allSlots.filter((slot) => !bookedSlots.includes(slot));

    res.json({
      success: true,
      date,
      availableSlots,
      bookedSlots,
      totalSlots: allSlots.length,
      availableCount: availableSlots.length,
    });
  } catch (error) {
    console.error('Get available slots error:', error);
    res.status(500).json({ success: false, error: 'Unable to fetch available time slots' });
  }
});

app.get('/api/appointments', async (req, res) => {
  try {
    const page = Number(req.query.page || 1);
    const limit = Number(req.query.limit || 10);
    const { status, date } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (date) {
      const d = new Date(date);
      const start = new Date(d);
      start.setHours(0, 0, 0, 0);
      const end = new Date(d);
      end.setHours(23, 59, 59, 999);
      filter.appointmentDate = { $gte: start, $lte: end };
    }

    const [appointments, total] = await Promise.all([
      Appointment.find(filter).sort({ createdAt: -1 }).limit(limit).skip((page - 1) * limit),
      Appointment.countDocuments(filter),
    ]);

    res.json({
      success: true,
      appointments,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total,
    });
  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({ success: false, error: 'Unable to fetch appointments' });
  }
});

// ---- Contact ----
app.post('/api/contact', async (req, res) => {
  try {
    const { name, phone, message, email } = req.body; // email optional
    const clientInfo = getClientInfo(req);

    if (!name || !phone || !message) {
      return res.status(400).json({ success: false, error: 'Please fill in all required fields: name, phone, and message' });
    }

    if (email && !validator.isEmail(email)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address' });
    }

    const contactMessage = new ContactMessage({
      name: name.trim(),
      phone: phone.trim(),
      email: email ? email.trim() : undefined,
      message: message.trim(),
      ...clientInfo,
    });

    await contactMessage.save();

    if (email) {
      try {
        const tpl = emailTemplates.contactConfirmation({ name, message });
        await transporter.sendMail({
          from: `"Blood Bank Connect" <${process.env.EMAIL_USER}>`,
          to: email,
          subject: tpl.subject,
          html: tpl.html,
        });
        console.log('✅ Contact confirmation email sent to:', email);
      } catch (emailError) {
        console.error('❌ User email sending failed:', emailError);
      }
    }

    try {
      await transporter.sendMail({
        from: `"Blood Bank Connect" <${process.env.EMAIL_USER}>`,
        to: process.env.ADMIN_EMAIL || process.env.EMAIL_USER,
        subject: '📬 New Contact Message - Blood Bank Connect',
        html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto"><h2 style="color:#ff4757">📬 New Contact Message</h2><div style="background:#f9f9f9;padding:20px;border-radius:5px"><p><strong>Name:</strong> ${name}</p><p><strong>Phone:</strong> ${phone}</p><p><strong>Email:</strong> ${email || 'Not provided'}</p><p><strong>Message:</strong></p><div style="background:#fff;padding:15px;border-radius:3px;margin:10px 0">${message}</div><p><strong>Received:</strong> ${new Date().toLocaleString()}</p><p><strong>IP Address:</strong> ${clientInfo.ipAddress}</p></div><p style="color:#666;font-size:12px">Please respond within 24 hours for optimal customer service.</p></div>`,
      });
      console.log('✅ Admin notification email sent');
    } catch (emailError) {
      console.error('❌ Admin email sending failed:', emailError);
    }

    res.json({ success: true, message: 'Thank you for your message! We will get back to you soon.', messageId: contactMessage._id });
  } catch (error) {
    console.error('Contact submission error:', error);
    res.status(500).json({ success: false, error: 'Unable to send message. Please try again or call us directly.' });
  }
});

app.get('/api/contact/messages', async (req, res) => {
  try {
    const page = Number(req.query.page || 1);
    const limit = Number(req.query.limit || 10);
    const { status } = req.query;

    const filter = {};
    if (status) filter.status = status;

    const [messages, total, unreadCount] = await Promise.all([
      ContactMessage.find(filter).sort({ createdAt: -1 }).limit(limit).skip((page - 1) * limit),
      ContactMessage.countDocuments(filter),
      ContactMessage.countDocuments({ status: 'new' }),
    ]);

    res.json({ success: true, messages, totalPages: Math.ceil(total / limit), currentPage: page, total, unreadCount });
  } catch (error) {
    console.error('Get contact messages error:', error);
    res.status(500).json({ success: false, error: 'Unable to fetch contact messages' });
  }
});

// ---- Locations ----
app.get('/api/locations', async (_req, res) => {
  try {
    const locations = await Location.find({ isActive: true }).sort({ createdAt: -1 });
    res.json({ success: true, locations });
  } catch (error) {
    console.error('Get locations error:', error);
    res.status(500).json({ success: false, error: 'Unable to fetch locations' });
  }
});

// (Optional) Seed a default location if none exists
app.post('/api/locations/seed', async (_req, res) => {
  try {
    const count = await Location.countDocuments();
    if (count > 0) return res.json({ success: true, message: 'Locations already seeded' });

    await Location.create({
      name: 'Blood Bank Connect – Kumasi Center',
      address: 'Local address',
      city: 'Kumasi',
      phone: '+233503489235',
      email: 'bloodbankconnect@gmail.com',
      operatingHours: {
        monday: { open: '09:00', close: '16:00' },
        tuesday: { open: '09:00', close: '16:00' },
        wednesday: { open: '09:00', close: '16:00' },
        thursday: { open: '09:00', close: '16:00' },
        friday: { open: '09:00', close: '16:00' },
        saturday: { open: '10:00', close: '14:00' },
        sunday: { open: '00:00', close: '00:00', closed: true },
      },
      coordinates: { latitude: 6.6918, longitude: -1.6308 },
    });

    res.json({ success: true, message: 'Default location seeded' });
  } catch (error) {
    console.error('Seed locations error:', error);
    res.status(500).json({ success: false, error: 'Unable to seed locations' });
  }
});

// ---- Newsletter ----
app.post('/api/newsletter/subscribe', async (req, res) => {
  try {
    const { email, name } = req.body;
    if (!email || !validator.isEmail(email)) {
      return res.status(400).json({ success: false, error: 'Valid email is required' });
    }

    const existing = await Newsletter.findOne({ email: email.toLowerCase() });
    if (existing) {
      existing.subscribed = true;
      existing.unsubscribedAt = null;
      existing.name = name || existing.name;
      await existing.save();
      return res.json({ success: true, message: 'You are subscribed already. Preferences updated.' });
    }

    await Newsletter.create({ email: email.toLowerCase(), name: name || undefined });
    res.json({ success: true, message: 'Subscription successful. Welcome aboard!' });
  } catch (error) {
    console.error('Newsletter subscribe error:', error);
    res.status(500).json({ success: false, error: 'Unable to subscribe at the moment' });
  }
});

app.post('/api/newsletter/unsubscribe', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || !validator.isEmail(email)) {
      return res.status(400).json({ success: false, error: 'Valid email is required' });
    }

    const n = await Newsletter.findOne({ email: email.toLowerCase() });
    if (!n) return res.status(404).json({ success: false, error: 'Subscription not found' });

    n.subscribed = false;
    n.unsubscribedAt = new Date();
    await n.save();
    res.json({ success: true, message: 'You have been unsubscribed' });
  } catch (error) {
    console.error('Newsletter unsubscribe error:', error);
    res.status(500).json({ success: false, error: 'Unable to unsubscribe at the moment' });
  }
});

app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ success: false, error: 'API endpoint not found' });
  }
  next();
});

app.use((err, _req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, error: 'Internal server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));

module.exports = app;


